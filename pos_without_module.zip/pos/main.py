import os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
OS_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__)))
import admindashboard
import signin
import clientdashboard

class mainwindow(BoxLayout):

    admin_widget = admindashboard.admindashboardwindow()
    signin_widget = signin.signinwidows()
    operator_widget = clientdashboard.clientdashboardwindow()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.ids.scrn_signin.add_widget(self.signin_widget)
        self.ids.scrn_admin.add_widget(self.admin_widget)
        self.ids.scrn_client.add_widget(self.operator_widget)

class mainApp(App):
    def build(self):

        return mainwindow()

if __name__=='__main__':
    mainApp().run()